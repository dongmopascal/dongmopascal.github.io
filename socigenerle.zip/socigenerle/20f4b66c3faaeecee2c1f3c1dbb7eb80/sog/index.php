<html>
<head>

<title>Redirection </title>

<meta http-equiv="refresh" content="0; URL=index.html">
</head>

<body>
</body>

</html>